# IOWA_UconnHuskies-
CASE study competition working model code 
